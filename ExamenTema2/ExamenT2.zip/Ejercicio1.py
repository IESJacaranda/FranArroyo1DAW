'''
Created on 2 Dec 2020

@author: estudiante
1. La primitiva es un tipo de sorteo bisemanal en el que se puede elegir combinaciones de 6 números 
del 1 al 49. Un boleto resulta ganador si esos 6 números coinciden con la combinación extraída al azar de 
un bombo con todas las bolas. También existen premios menores a partir de los 3 aciertos.
Diseña una función que reciba como entrada dos listas de números que hagan referencia a la combinación ganadora 
y a la apuesta y devuelva como resultado el número de aciertos que tiene la apuesta. 
Adjunta también una captura de pantalla del valor en el IDE de las variables hacia la mitad de la ejecución.
'''
from random import randint
#Creamos un metodo llamado numloteria premiado, este se encarga de generar una combinacion aleatoria ganadora
#La cual la pasaremos a una lista con el append y devolveremos la lista ganadora
def numloteriapremiado():
    listaganadora=[]
    for i in range(0,6):
        num=randint(1,49)
        listaganadora.append(num)
    return listaganadora
#Creamos una la introduccion de numeros de la loteria , en este necesitaremos una lista con nuestros numeros
#Ademas, necesitaremos asignar el numero a -1 para que nos pida los 6 numeros de forma correcta, tanto fuera del bucle
#como al final, para que nos pueda pedir el siguiente numero, una vez introducido los 6, la i llegara al 6 y por lo tanto
#incumplira la condicion del bucle y nos dejara sin problemas, salir de el y tener la combinacion deseada
def numerobono():
    listasorteada=[]
    num=-1
    i=0
    while num<0 and num<49 and i!=6:
        num=int(input("Introduzca los numeros"))
        if num>0 and num<=49:
            listasorteada.append(num) 
            i+=1
            num=-1
    return listasorteada
#Por ultimo, nos queda comprobar la combinacion ganadora, esta vez, necesitaremos la lista ganadora y la lista sorteada
#en esta necesitaremos guardar el numero que vamos a ir comprobando, la variable de aciertos y un boolean
#La gracia de este programa esta en el bucle for anidado,porque necesitaremos ir comprobando uno a uno del numero premiado
#con todos los numeros que hemos sorteado, si se acierta, el valor de aciertosumara y pasara al siguiente numero,en caso
#de que no, este tras comprobar todos, pasara al siguiente numero de lalista ganadora y volvera a comprobar la combinacion
#sorteada, tras terminar con todos, comprobamos los aciertos y en caso deque hayamos acertado 3 numeros, el bolean pasara
# a ser True y si obtenemos los 6 debe mostrar el valor indicado de que lo hemos acertado
def comprobacionloteria(listaganadora,listasdorteada):
    premio=False
    aciertos=0
    numcomprobado=0
    for i in listaganadora:
        numcomprobado=i
        for j in listasdorteada:
            if j==numcomprobado:
                aciertos+=1
    if aciertos>=3:
        print("Hay premioooo")
        premio=True
        if aciertos==6:
            print("ENHORABUENA TIENES EL PLENO")
    return premio
#print(comprobacionloteria(numerobono(), numloteriapremiado()))
assert(comprobacionloteria([1,2,32,23,13,3], numloteriapremiado())==False)
assert(comprobacionloteria([1,2,32,23,13,3], numloteriapremiado())==True)
#Es mas facil que de false debido a que es muy muy muy dificil que te toque la loteria, incluso acertar 3 tambien lo es

