'''
Created on 9 Dec 2020

@author: xXxArroyoxXx
'''

#Este metodo se copia del ejercicio 2 , lo de validar dni,el cual tengo foto del codigo en el telefono.
def validardni(dni):
    return False
#Esto recibe el nombre ,apellidos sin espacio entre ellos, separados por coma y devuelve una lista con lo anteriores
#datos de forma individual
def separarcadena(nombre):
    lista=[]
    tmp=[]
    for i in nombre:
        if i!=",":
            tmp+=i
        else:
            lista.append(tmp)
            tmp=""
    lista.append(tmp)
    return lista

#A partir del nombre y apellidos junto al dni construye un identificador de usuario de como maximo 12 caracteres
def generaIdusuario(listaindentificadores,dni):
    idusuario=""
    listaindentificadores.append(dni)
    for i in range(0,len(listaindentificadores)):
        listaindentificadores[i]
        nombre=listaindentificadores[0]
        apellido1=listaindentificadores[1]
        apellido2=listaindentificadores[2]
        idusuario+=nombre[0]+nombre[1]+nombre[2]+apellido1[-3]+apellido1[-2]+apellido1[-1]
        idusuario+=apellido2[0]+apellido2[1]+apellido2[2]
        idusuario+=dni[0]+dni[1]+dni[2]
    
    
    
    return idusuario
def funcionprincipal():
    nombreapellidos=input("Introduce el nombre y apellidos")
    dni=input("Introduce el dni")
    while (not(esDniValido(dni))):
        dni=input("Introduce el dni")
    
    print("El id de usuario es: "+generaIdusuario(nombreapellidos, dni))
    
    


