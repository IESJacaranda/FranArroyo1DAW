'''
Created on 2 Dec 2020

@author: estudiante

Realizar una función que reciba como parámetro una cadena que contenga un dni y devuelva un 
True si el dni es válido y False en caso contrario. Para calcular la letra debemos tomar el 
número completo de hasta 8 cifras de nuestro DNI, lo dividimos entre 23 y nos quedamos con el resto de dicha división.
El resultado anterior es un número entre 0 y 22. A cada uno de estos posibles números le corresponde 
una letra, según la siguiente tabla:
Si el formato no es válido deberá devolver False.
Mejora opcional: Ten en cuenta que hay dni que en vez de 8 números pueden tener 7.
Entrega las pruebas que has realizado
'''
#Este metodo es opcional , pues solo es creado , en caso que nosotros queramos pedir al usuario el dni, basicamente espedir
#una lista con los numeros y luego transformarlos en una cadena para su posterior uso en el ejercicio de validacion del dni
def dni():
    dni=[]
    dnii=""
    for i in range(0,8):
        num=input("Introduce el dni")
        dni.append(num)
    for i in dni:
        dnii+=i
    return dnii
#Le pasamos el valor de dni, convertimos la cadena en un int para que podamos realizar operaciones matematicas con este
#Luego realizamos la operacion y en caso que el resto sea igual o mayor a 23 , ese dni no sera valido
#En caso de que el resto sea menor a la condicion, creamos una lista con las letras necesarias, y asignaremos la posicion con el resto
#Lo que nos dara la letra, y por ultimo generamos el dni completo, y nos devueve true para confirmar que todo bien
def validaciondni(dnii):
    dnii=int(dnii)
    resto=dnii%23
    if resto>=23:
        return False
    else:
        letras=["T","R","W","A","G","M","Y","F","P","D","X","B","N","J","Z","S","Q","V","H","L","C","K","E"]
        letra=letras[resto]
        dnicompleto=str(dnii)+letra
        return True
assert(validaciondni(dnii="30131888")==True)
assert(validaciondni(dnii="30518211")==True)

