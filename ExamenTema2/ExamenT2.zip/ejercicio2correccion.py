'''
Created on 3 Dec 2020

@author: estudiante
'''
def esvalidodni (dni):
    valido=False
    return valido


'''
assert(not esvalidodni("14141414W"))
assert(not esvalidodni("77777777W"))
'''