import random
def generacombinacionganadora():
    combinacionganadora=[]
    i=0
    while i<6:
        numero=random.randint(1,49)
        if numero not in combinacionganadora:
            combinacionganadora.append(numero)
            i+=1
    return combinacionganadora

def calculaaciertos(ganadora,apuestas):
    numaciertos=0
    if len(ganadora)==6 and len(apuestas)==6:
        #Comprueba combinacion
        for i in apuestas:
            for j in apuestas:
                if i==j:
                    numaciertos+=1
    return 0
ganadora=[34,23,12,45,5,3]
def compruebaapuestas(ganadora):
    mensaje=""
    pleno="Enhorabuena tienes pleno"
    apuestas=[]
    for i in range(6):
        num=int(input("Introduce el numero"))
        while (num>50 or num<1 or num in apuestas):
            num=int(input("Introduce el numero"))
        apuestas.append(num)
    numaciertos=calculaaciertos(ganadora, apuestas)
    
    if numaciertos==6:
        mensaje=pleno
    elif numaciertos>=3:
        mensaje+="Tienes %s aciertos"%numaciertos
    else:
        mensaje="Pruebe de nuevo"

assert(calculaaciertos([],[])==0)
assert(calculaaciertos([3,43,12,41,1,6],[3,12,43,9,5,10])==3)
assert(calculaaciertos([],[])==0)