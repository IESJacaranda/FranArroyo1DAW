'''
Created on 26 Nov 2020

@author: estudiante
'''
def cuentavocales(cadenaentrada):
    for i in cadenaentrada:
        
        
        
        
        
        
cadenaentrada="AEIOUs"