'''
Created on 2 Dec 2020

@author: estudiante
Realizar un programa que nos sirva para crear el id de usuario que nuestros empleados 
utilizarán para conectarse a nuestras aplicaciones. El programa debe preguntarle al usuario 
su nombre y sus apellidos, separando los datos por coma. Es decir si me preguntan a mi yo 
debo poner JoséManuel,Sevillano,Armenta (puedes suponer que nos van a dar los valores bien). 
Luego debe preguntar el dni, debe comprobar que se trata de un dni válido, si no es válido volver 
a preguntarlo hasta que nos dé un dni válido. Por último debe llamar a una función que devuelva el id. 
Para calcular el id le pasaremos la cadena con el nombre y apellidos y creará el id con los tres 
primeros caracteres del nombre, los tres últimos del primer apellido ,
 los tres primeros del segundo apellido y los tres primeros números del dni.
'''
cadena="Francisco,arroyo,delatorre,123123123D"
# def id(cadena):
#     nombre=""
#     apellidouno=""
#     apellidodos=""
#     dni=""
#     for i in range(0,len(cadena)):
#         if cadena[i:3]==",":
#             nombre+=nombre+cadena[i]
# 
#     return nombre
# print(id(cadena))
def introduciondatos():
    datos=input("Introduce los datos del nombre,apellido1, apellido2,dni separados por coma")
    nombre=""
    apellidouno=""
    apellidodos=""
    dni=""
    i=0
#Con los while voy recorriendo y comprobando las i , luego con esta añado las 3 primeras a una lista
#posteriormente, con otra variable guardo la ultima posicion y se la paso al proximo while y asi sucesivamente, hastta
#tener todos los datos
    while i!=len(datos):
        nombre+=nombre+datos[i]
        i+=1
        ultimai=i
        if datos[i]==",":
            i=len(datos)
        while ultimai!=len(datos):
            apellidouno+=datos[ultimai]
            ultimai+=1
            ultimaapellido=ultimai
            if datos[ultimai]==",":
                ultimai=len(datos)
        while ultimaapellido!=len(datos):
            apellidodos+=datos[ultimaapellido]
            ultimaapellido+=1
            ultimaapellidodos=ultimaapellido
#Por ultimo cojo esos tres ultimos y se los anado a una id y la devuelvo
    for i in nombre:
        id=nombre[0:3]
    for i in apellidouno:
        id=id+apellidouno[0:3]
    for i in apellidodos:
        id=id+apellidodos[0:3]
    return id
print(introduciondatos())







    