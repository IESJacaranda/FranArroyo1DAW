'''
Design a method called friend that receives two positive number as parameters. 
The method should return true if the number are friends and false in other case. 
Two numbers are friends if the addition of all the divisors (itself is not considered)
of one number equals the other one and viceversa. If the parameters are not valid the 
method should return false.
'''